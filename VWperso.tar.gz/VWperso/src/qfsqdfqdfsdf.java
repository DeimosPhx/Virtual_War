
public class qfsqdfqdfsdf {
/*
	public static void main(String[] args) {
		String tamaman = "    Hello    Woooooorld !!!!    ";
		String[] vosmamans = tamaman.trim().split(" +");
		System.out.println(vosmamans[0]);
		System.out.println(vosmamans[1]);
		System.out.println(vosmamans[2]);

	}

}
*/
}