package vwperso.terrain;

import java.util.ArrayList;
import vwperso.unite.Robot;

public class Base extends Case{
	private int equipe;
	private ArrayList<Robot> robotEnBase = new ArrayList<Robot>();
	
	public Base(int equipe){
		this.equipe = equipe;
	}
	public ArrayList<Robot> getRobotEnBase(){
		return robotEnBase;
	}
	public int getEquipe(){
		return this.equipe;
	}
}
