package vwperso.terrain;
import vwperso.unite.Robot;

public class Case {
	private boolean obstacle;
	private int mine;
	protected Robot robot;
	
	public Case(){
		obstacle = false;
		mine = 0;
	}
	public Case(boolean obstacle){
		this.obstacle = true;
	}
	public boolean getObstacle(){
		return obstacle;
	}
	public String toString(){
		if(robot == null){
			return " ";
		}
		return robot + "" ;
	}
	public void setMine(int mine){
		this.mine = mine;
	}
	public int getMine(){
		return this.mine;
	}
	public void setRobot(Robot robot){
		this.robot = robot;
	}
	public Robot getRobot(){
		return robot;
	}
}
