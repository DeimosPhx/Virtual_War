package vwperso.terrain;

public class Plateau {
	public static Case[][] plateau = new Case[10][10];
}
