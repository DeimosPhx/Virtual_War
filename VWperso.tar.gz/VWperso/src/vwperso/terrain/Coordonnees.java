package vwperso.terrain;

public class Coordonnees {
	private int abscisse;
	private int ordonnee;
	
	public Coordonnees(int abscisse, int ordonnee){
		this.abscisse = abscisse;
		this.ordonnee = ordonnee;
	}

	public int getAbscisse() {
		return abscisse;
	}

	public int getOrdonnee() {
		return ordonnee;
	}
	public Coordonnees cibler(Direction direction){
		return new Coordonnees(abscisse + direction.getCoordonnees().abscisse, ordonnee + direction.getCoordonnees().ordonnee);
	}
}
