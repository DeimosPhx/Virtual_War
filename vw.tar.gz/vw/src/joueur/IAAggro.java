package joueur;

import java.util.ArrayList;
import java.util.Random;

import terrain.Base;
import terrain.Direction;
import terrain.Plateau;
import unite.Char;
import unite.Piegeur;
import unite.Robot;
import unite.Tireur;

public class IAAggro extends Joueur{
	private Random r = new Random();
	public IAAggro(int equipe) {
		super(equipe);
		// TODO Auto-generated constructor stub
	}

	public IAAggro(int equipe, Base base, Vue vue) {
		super(equipe, base, vue);
		// TODO Auto-generated constructor stub
	}

	public Robot selecUnite() {
		int taille = super.getListeRobot().size()-1;
		int numRobot = r.nextInt(taille);
		return super.getListeRobot().get(numRobot);
	}

	public void action(Robot rob,Plateau ter) {
		boolean fini = false;
		Robot selected = super.getRobot(0);
		for(Robot r : super.getListeRobot()){
			if(super.equipe == 1){
				if(r.getCord().getAbscisse()<selected.getCord().getAbscisse() || r.getCord().getOrdonnee() < r.getCord().getOrdonnee()){
					selected = r;
				}
			}
			else{
				if(r.getCord().getAbscisse()>selected.getCord().getAbscisse() || r.getCord().getOrdonnee() > r.getCord().getOrdonnee()){
					selected = r;
				}
			}
			
		}
		/*
		 * tir si enemie a port�
		 */
		ArrayList<Direction> toTarget = Direction.BAS.getList();
		for(Direction target : toTarget){
			if(!fini && selected.peutTirer(target)){
				fini = true;
				selected.tirer(target);
			}
		}
		/*
		 * sinon mouvement vers enemie + proche
		 */
		for(Direction target : toTarget){
			if(!fini && super.equipe == 1 && ter.peuxDeplacer(this, selected, target)){
				fini = true;
				ter.deplacerTest(this, selected, target);
			}
			else if(!fini && ter.peuxDeplacer(this, selected, target)){
				fini = true;
				ter.deplacerTest(this, selected, target);
			}
		}
	}

}
