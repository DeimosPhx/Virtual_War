package terrain;

import java.util.ArrayList;

public enum Direction {
	HAUT(new Coordonnees(-1, 0)), BAS(new Coordonnees(1, 0)), DROITE(new Coordonnees(0, 1)), GAUCHE(
			new Coordonnees(0, -1)), HAUT_GAUCHE(new Coordonnees(-1, -1)), HAUT_DROITE(
					new Coordonnees(-1, 1)), BAS_GAUCHE(new Coordonnees(1, -1)), BAS_DROITE(new Coordonnees(1, 1));

	private Coordonnees direction;

	private Direction(Coordonnees direction) {
		this.direction = direction;
	}

	public Coordonnees getCoordonnees() {
		return direction;
	}
	public ArrayList<Direction> getList(){
		ArrayList<Direction> res = new ArrayList<Direction>();
		res.add(HAUT);
		res.add(BAS);
		res.add(DROITE);
		res.add(GAUCHE);
		res.add(HAUT_GAUCHE);
		res.add(HAUT_DROITE);
		res.add(BAS_DROITE);
		res.add(BAS_GAUCHE);
		return res;
	}
}