package terrain;

public class Obstacle extends Parcelle {
	public Obstacle(Coordonnees cord) {
		super(cord);
	}

	public String toString() {
		return "O";
	}
}
