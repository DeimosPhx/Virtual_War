package Terrain;

public class Parcelle {
	private Coordonnees cord;
	protected int equipe;
	
	public int getEquipe(){
		return equipe;
	}
	public void setEquipe(int equipe){
		this.equipe = equipe;
	}
	public Parcelle(Coordonnees cord){
		this.cord = cord;
	}
	public boolean estVide(){
		return true;
	}
	public Coordonnees getCord(){
		return this.cord;
	}
	public String toString(){
		return " ";
	}
}
