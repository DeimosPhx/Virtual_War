package joueur;

import java.awt.Paint;
import java.awt.PaintContext;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.ColorModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.swing.JOptionPane;

import com.sun.prism.paint.Color;

import terrain.Base;
import terrain.Coordonnees;
import terrain.Direction;
import terrain.Obstacle;
import terrain.Parcelle;
import terrain.Plateau;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import unite.Char;
import unite.Mine;
import unite.Piegeur;
import unite.Robot;
import unite.Tireur;

public class Jeu extends Application{

	private int tauxObstacle, tailleX = 10, tailleY=10;
	private HashMap<Integer,Robot> compojoueur1 = new HashMap<Integer,Robot>();
	private HashMap<Integer,Robot> compoJ2 = new HashMap<Integer,Robot>();
	boolean joueur1EstHumain, joueur2EstHumain;
	private Base B1,B2;
	private Vue vuejoueur1, vueJ2;
	private Joueur joueur1,joueur2;
	private Plateau plateau;
	private static HashMap<String,Image> images= new HashMap<String,Image>();
	private static final int tailleParcelle=50;
	private boolean tourjoueur1 = true;
	private Robot selectedRobot = null;

	private static void initialisation(){
		images.put("herbe"		,new Image("Herbe.png"	));
		images.put("1obstacle"	,new Image("Montagne.png"));
		images.put("2obstacle"	,new Image("Foret.png"	));
		images.put("1base"		,new Image("Base1.png"	));
		images.put("2base"		,new Image("Base2.png"	));
		images.put("1char"		,new Image("Char1.png"	));
		images.put("2char"		,new Image("Char2.png"	));
		images.put("1tireur"	,new Image("Tireur1.png"));
		images.put("2tireur"	,new Image("Tireur2.png"));
		images.put("1piegeur"	,new Image("piegeur1.png"));
		images.put("2piegeur"	,new Image("piegeur2.png"));
		images.put("1mine"		,new Image("Mine1.png"	));
		images.put("2mine"		,new Image("Mine2.png"	));
		images.put("1charBase"	,new Image("charDansBase.png"));
		images.put("1tireurBase",new Image("infanterieDansbase.png"));
		images.put("1piegeurBase",new Image("piegeurDansBase.png"));
		images.put("2charBase"	,new Image("charDansBase2.png"));
		images.put("2tireurBase",new Image("infanterieDansBaseJ2.png"));
		images.put("2piegeurBase",new Image("piegeurDansBaseJ2.png"));
		images.put("1herbe",	new Image("HerbeJ1.png"));
		images.put("2herbe",	new Image("HerbeJ2.png"));
		images.put("combat", 	new Image("combat.png"));

	}

	private void setUniteDansbase(){
		ArrayList<Robot> lstjoueur1 = new ArrayList<Robot>();
		for(int i=0;i<compojoueur1.size();i++){
			lstjoueur1.add(compojoueur1.get(new Integer(i)));
		}
		ArrayList<Robot> lstJ2 = new ArrayList<Robot>();
		for(int i=0;i<compoJ2.size();i++){
			lstJ2.add(compoJ2.get(new Integer(i)));
		}
		B1.setList(lstjoueur1);
		B2.setList(lstJ2);
	}

	public void setReglage(int tauxObstacle,boolean joueur1EstHumain,boolean joueur2EstHumain,int nbCharjoueur1,int nbCharJ2,int nbTireurjoueur1,int nbTireurJ2,int nbPiegeurjoueur1,int nbPiegeurJ2){
		this.tauxObstacle = tauxObstacle;
		setCompo( nbCharjoueur1, nbCharJ2, nbTireurjoueur1, nbTireurJ2, nbPiegeurjoueur1, nbPiegeurJ2, plateau);
		this.joueur1EstHumain = joueur1EstHumain;
		this.joueur2EstHumain = joueur2EstHumain;
		this.B1 = new Base(new Coordonnees(0,0),1);
		this.B2 = new Base(new Coordonnees(tailleX-1,tailleY-1),2);
		plateau = new Plateau(tailleX, tailleY);
		plateau.setBase(B1);
		plateau.setBase(B2);
		vuejoueur1 = new Vue(1,plateau);
		vueJ2 = new Vue(2,plateau);

		//A CHANGER SI IA
		joueur1 = new Joueur(1,B1,vuejoueur1);
		joueur2 = new Joueur(2,B2,vueJ2);

		setCompo(nbCharjoueur1, nbCharJ2, nbTireurjoueur1, nbTireurJ2, nbPiegeurjoueur1, nbPiegeurJ2, plateau);
		joueur1.setList(compojoueur1);
		joueur2.setList(compoJ2);
		setObstacle(plateau, joueur1, joueur2, tauxObstacle);
		setUniteDansbase();

		initialisation();
	}

	public void setCompo(int nbCharjoueur1,int nbCharJ2,int nbTireurjoueur1,int nbTireurJ2,int nbPiegeurjoueur1,int nbPiegeurJ2, Plateau plateau){
		int cptjoueur1 = 0;
		int cptJ2 = 0;

		for(int i = 0; i<nbCharjoueur1; i++){
			compojoueur1.put(cptjoueur1,new Char(1,new Coordonnees(0, 0), plateau));
			cptjoueur1++;
		}
		for(int i = 0; i<nbCharJ2; i++){
			compoJ2.put(cptJ2,new Char(2,new Coordonnees(tailleX-1, tailleY-1), plateau));
			cptJ2++;
		}
		for(int i = 0; i<nbTireurjoueur1; i++){
			compojoueur1.put(cptjoueur1,new Tireur(1,new Coordonnees(0, 0), plateau));
			cptjoueur1++;
		}
		for(int i = 0; i<nbTireurJ2; i++){
			compoJ2.put(cptJ2,new Tireur(2,new Coordonnees(tailleX-1, tailleY-1), plateau));
			cptJ2++;
		}
		for(int i = 0; i<nbPiegeurjoueur1; i++){
			compojoueur1.put(cptjoueur1,new Piegeur(1,new Coordonnees(0, 0), plateau));
			cptjoueur1++;
		}
		for(int i = 0; i<nbPiegeurJ2; i++){
			compoJ2.put(cptJ2,new Piegeur(2,new Coordonnees(tailleX-1, tailleY-1), plateau));
			cptJ2++;
		}

	}

	public static void setObstacle(Plateau ter,Joueur joueur1,Joueur j2,int tauxObstacle){
		/*
		 * on genere les obstacles selon le taux
		 * en s'assurant qu'il existe un chemin d'une base a l'autre
		 */
		Parcelle[][] plat = ter.getGrille();
		int tx= tauxObstacle;
		//plateau de 100case (10*10)
		//EZ taux
		Random rnd = new Random();
		boolean isOut = false;
		for(int i=0;i<tx;i++){
			do{
				isOut = false;
				int x = rnd.nextInt(9);
				int y = rnd.nextInt(9);
				/*if((x!=joueur1.getBase().getCord().getAbscisse() && y!=joueur1.getBase().getCord().getOrdonnee()) 
	        			&& (x!=j2.getBase().getCord().getAbscisse() && y!=j2.getBase().getCord().getOrdonnee())
	        			&& (x!=joueur1.getBase().getCord().getAbscisse()+1 && y!=joueur1.getBase().getCord().getOrdonnee()+1)
	        			&& (x!=j2.getBase().getCord().getAbscisse()+1 && y!=j2.getBase().getCord().getOrdonnee()+1))*/
				if(plat[x][y].autoriserPlacementObstacle(ter,new Coordonnees(x,y))){
					plat[x][y] = new Obstacle(new Coordonnees(x,y));
					plat[x][y].setPasVide();
					isOut = true;
				}
			}while(!isOut);
		}
	}

	public void draw(GraphicsContext gc){
		gc.clearRect(0, 0,tailleX*tailleParcelle,tailleY*tailleParcelle+160);
		//AFFICHER LES UNITES DANS LA BASE :
		for(int i=0;i<B1.getTailleListe();i++){
			if		(B1.getRobot(i) instanceof Char){
				gc.drawImage(images.get("1charBase"), i*50, 0);
			}else if(B1.getRobot(i) instanceof Tireur){
				gc.drawImage(images.get("1tireurBase"), i*50, 0);
			}else if(B1.getRobot(i) instanceof Piegeur){
				gc.drawImage(images.get("1piegeurBase"), i*50, 0);
			}
		}
		for(int i=0;i<B2.getTailleListe();i++){
			if		(B2.getRobot(i) instanceof Char){
				gc.drawImage(images.get("2charBase"), 450-i*50, 90+tailleY*50);
			}else if(B2.getRobot(i) instanceof Tireur){
				gc.drawImage(images.get("2tireurBase"), 450-i*50, 90+tailleY*50);
			}else if(B2.getRobot(i) instanceof Piegeur){
				gc.drawImage(images.get("2piegeurBase"), 450-i*50, 90+tailleY*50);
			}
		}

		//AFFICHER LE PLATEAUDE JEU
		for (int x=0; x<tailleX; x++){
			for (int y=0; y<tailleY; y++){
				if 	  (Plateau.grille[x][y] instanceof Char) {
					if(Plateau.grille[x][y].getEquipe()==1){
						gc.drawImage(images.get("1char"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else{
						gc.drawImage(images.get("2char"),x*tailleParcelle,y*tailleParcelle+80);
					}
				}
				else if(Plateau.grille[x][y] instanceof Obstacle) {
					gc.drawImage(images.get("1obstacle"),x*tailleParcelle,y*tailleParcelle+80);
				}
				else if(Plateau.grille[x][y] instanceof Base) {
					if(Plateau.grille[x][y].getEquipe()==1){
						gc.drawImage(images.get("1base"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else{
						gc.drawImage(images.get("2base"),x*tailleParcelle,y*tailleParcelle+80);
					}
				}
				else if(Plateau.grille[x][y] instanceof Tireur) {
					if(Plateau.grille[x][y].getEquipe()==1){
						gc.drawImage(images.get("1tireur"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else{
						gc.drawImage(images.get("2tireur"),x*tailleParcelle,y*tailleParcelle+80);
					}
				}
				else if(Plateau.grille[x][y] instanceof Mine) {
					if(Plateau.grille[x][y].getEquipe()==1 && tourjoueur1){
						gc.drawImage(images.get("1mine"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else if(Plateau.grille[x][y].getEquipe()==2 && !tourjoueur1){
						gc.drawImage(images.get("2mine"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else{
						gc.drawImage(images.get("herbe"),x*tailleParcelle,y*tailleParcelle+80);
					}
				}
				else if(Plateau.grille[x][y] instanceof Piegeur) {
					if(Plateau.grille[x][y].getEquipe()==1){
						gc.drawImage(images.get("1piegeur"),x*tailleParcelle,y*tailleParcelle+80);
					}
					else{
						gc.drawImage(images.get("2piegeur"),x*tailleParcelle,y*tailleParcelle+80);
					}
				}
				else {gc.drawImage(images.get("herbe"),x*tailleParcelle,y*tailleParcelle+80);}}}

		//ON VAS AFFICHER LE ROBOT ACTUELLEMENT SELECTIONNER :
		if(selectedRobot != null){
			if(selectedRobot.getEquipe()==1){}
			else{}
			gc.strokeRect(selectedRobot.getAbscisse()*tailleParcelle, selectedRobot.getOrdonnee()*tailleParcelle+80, tailleParcelle, tailleParcelle);
		}
		//Affichons l'interface dynamique :

		//deplacement
		for (int x=0; x<tailleX; x++){
			for (int y=0; y<tailleY; y++){
				if(selectedRobot!=null){
					for(Direction d : Direction.values()){
						if(plateau.peuxDeplacer(joueur1, selectedRobot, d) 
								&& x==selectedRobot.getAbscisse()+d.getCoordonnees().getAbscisse()
								&& y==selectedRobot.getOrdonnee()+d.getCoordonnees().getOrdonnee()){
							if(selectedRobot.getEquipe()==1){gc.drawImage(images.get("1herbe"),x*tailleParcelle,y*tailleParcelle+80);}
							else{gc.drawImage(images.get("2herbe"),x*tailleParcelle,y*tailleParcelle+80);}
						}
					}
				}
			}
		}
		//combat
		if(selectedRobot!=null){
			for (int x=0; x<tailleX; x++){
				for (int y=0; y<tailleY; y++){
					for(Direction d : Direction.values()){
						if(selectedRobot.peutTirer(d) && 
								x ==(selectedRobot.getAbscisse()+d.getCoordonnees().getAbscisse()) && 
								y ==(selectedRobot.getOrdonnee()+d.getCoordonnees().getOrdonnee())){
							gc.drawImage(images.get("combat"),selectedRobot.getRobotFromPlateau(d).getAbscisse()*tailleParcelle,selectedRobot.getRobotFromPlateau(d).getOrdonnee()*tailleParcelle+80);
						}
					}
				}
			}
		}

	}


	private ArrayList<Hitboxe> getHitboxes(HashMap<Integer,Robot> unites){
		ArrayList<Hitboxe> hitboxes = new ArrayList<Hitboxe>();
		if(unites.get(0).getEquipe()==1){
			for(int i =0; i<B1.getTailleListe();i++){
				hitboxes.add(new Hitboxe(new Rectangle(i*50,0,tailleParcelle,tailleParcelle),B1.getRobot(i)));
			}
			for(int i =0; i<unites.size();i++){
				if(!(B1.estDans(unites.get(i)))){
					hitboxes.add(new Hitboxe(new Rectangle(unites.get(i).getAbscisse()*tailleParcelle ,
							unites.get(i).getOrdonnee()*tailleParcelle+80,
							tailleParcelle,tailleParcelle),unites.get(i)));
				}
			}
		}
		else{
			for(int i =0; i<B2.getTailleListe();i++){
				hitboxes.add(new Hitboxe(new Rectangle(450-i*50, 90+tailleY*50,tailleParcelle,tailleParcelle),B2.getRobot(i)));
			}
			for(int i =0; i<unites.size();i++){

				if(!(B2.estDans(unites.get(i)))){
					hitboxes.add(new Hitboxe(new Rectangle(unites.get(i).getAbscisse()*tailleParcelle ,
							unites.get(i).getOrdonnee()*tailleParcelle+80,
							tailleParcelle,tailleParcelle),unites.get(i)));
				}
			}

		}
		return hitboxes;

	}
	private ArrayList<Hitboxe> getHitboxes(Robot robot){
		ArrayList<Hitboxe> out = new ArrayList<Hitboxe>();
		for (int x=0; x<tailleX; x++){
			for (int y=0; y<tailleY; y++){
				for(Direction d : Direction.values()){
					if(plateau.peuxDeplacer(joueur1, robot, d) 
							&& x==selectedRobot.getAbscisse()+d.getCoordonnees().getAbscisse()
							&& y==selectedRobot.getOrdonnee()+d.getCoordonnees().getOrdonnee()){
						out.add(new Hitboxe(new Rectangle(x*tailleParcelle,y*tailleParcelle+80, tailleParcelle,tailleParcelle),robot,d));
					}
				}
			}
		}
		return out;
	}

	private ArrayList<Hitboxe> getHitboxesPourTaper(Robot robot){
		ArrayList<Hitboxe> out = new ArrayList<Hitboxe>();
				for(Direction d : Direction.values()){
					if(robot.peutTirer(d)){
						out.add(new Hitboxe(new Rectangle((robot.getRobotFromPlateau(d).getAbscisse())*tailleParcelle,robot.getRobotFromPlateau(d).getOrdonnee()*tailleParcelle+80,tailleParcelle,tailleParcelle), robot, d));
					}
				}
		return out;
	}
	private void finDuTour(){
		tourjoueur1 = !tourjoueur1;
		Robot robotMort = null;
		do{
			robotMort = null;
			for(int i = 0;i<joueur1.getListeRobot().size();i++){
				if(joueur1.getListeRobot().get(i).getEnergie()<=0){
					robotMort = joueur1.getListeRobot().get(i);
				}
			}
			if(robotMort != null){
				joueur1.getListeRobot().remove(robotMort);
				Plateau.grille[robotMort.getAbscisse()][robotMort.getOrdonnee()]=new Parcelle(robotMort.getCord());
			}
		}while(robotMort != null);
		do{
			robotMort = null;
			for(int i = 0;i<joueur2.getListeRobot().size();i++){
				if(joueur2.getListeRobot().get(i).getEnergie()<=0){
					robotMort = joueur2.getListeRobot().get(i);
				}
			}
			if(robotMort !=null){
				joueur2.getListeRobot().remove(robotMort);
				Plateau.grille[robotMort.getAbscisse()][robotMort.getOrdonnee()]=new Parcelle(robotMort.getCord());
			}
		}while(robotMort != null);
	}
	
	public void start(Stage stage) throws Exception {
		stage.close();
		Canvas canvas = new Canvas(tailleX*tailleParcelle,tailleY*tailleParcelle+160);
		VBox root = new VBox();
		GraphicsContext gcJeu = canvas.getGraphicsContext2D();
		root.getChildren().add(canvas);
		Scene sceneJeu = new Scene(root);
		stage.setScene(sceneJeu);
		stage.show();
		draw(gcJeu);
		canvas.setOnMouseClicked(e -> {
			boolean hasFindSomething = false;
			if(tourjoueur1){
				for(Hitboxe h : getHitboxes(joueur1.getListeRobot())){
					if(h.getHitboxe().contains(new Point2D(e.getSceneX(),e.getSceneY()))){
						selectedRobot=h.getRobot();
						hasFindSomething = true;
					}
				}}else{
					for(Hitboxe h : getHitboxes(joueur2.getListeRobot())){
						if(h.getHitboxe().contains(new Point2D(e.getSceneX(),e.getSceneY()))){
							selectedRobot=h.getRobot();
							hasFindSomething = true;
						}
					}}
			if(selectedRobot != null){
				for(Hitboxe h : getHitboxes(selectedRobot)){
					if(h.getHitboxe().contains(new Point2D(e.getSceneX(),e.getSceneY()))){
						if(selectedRobot.getEquipe()==1){
							plateau.deplacerTest(joueur1, selectedRobot, h.getDirection());finDuTour();
							if(selectedRobot instanceof Char){plateau.deplacerTest(joueur1, selectedRobot, h.getDirection());}
						}
						else{plateau.deplacerTest(joueur2, selectedRobot, h.getDirection());finDuTour();
						if(selectedRobot instanceof Char){plateau.deplacerTest(joueur2, selectedRobot, h.getDirection());}}
					}
				}
				for (int x=0; x<tailleX; x++){
					for (int y=0; y<tailleY; y++){
						for(Direction d : Direction.values()){
							if(selectedRobot.peutTirer(d) && 
									x ==(selectedRobot.getAbscisse()+d.getCoordonnees().getAbscisse()) && 
									y ==(selectedRobot.getOrdonnee()+d.getCoordonnees().getOrdonnee())){
								selectedRobot.tirer(d);finDuTour();System.out.println("flag");
							}
						}
					}
				}
				System.out.println(""+selectedRobot.getEnergie());
			}
			if(!hasFindSomething){selectedRobot = null;}




			draw(gcJeu);
		});


	}

}
